#**********Water Demand Prediction in an agriculture field \n for the primary crop using machine learning****************

from tkinter import *
from PIL import Image, ImageTk
import requests
from tkinter import messagebox
import os
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


def tent_output():
    global r_frame, t_frame, out_frame, bg_pht, name, value
    
    # forgetting the r_frame if it exists
    if 'r_frame' in globals() and r_frame is not None:
        r_frame.place_forget()
    
    # t_frame creation - create first, then place
    t_frame = Frame(fapp, bg='palegreen', bd=2)
    t_frame.place(x=80, y=100, height=600, width=1400)
    
    # out_frame creation inside the t_frame
    out_frame = Frame(t_frame, bg='white', bd=2)
    out_frame.place(x=90, y=130, height=350, width=1250)
    
    # Background image
    bg_label = Label(t_frame, image=bg_pht)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
    bg_label.lower()  # Send to back
    
    # Labels and Entries
    Label(out_frame, text='The Water Prediction Result', fg='white', bg='black', font=('georgia', 30)).place(x=330, y=20)
    
    # Create entry widgets and fill with prediction data
    wheat_entry = Entry(out_frame, highlightthickness=3, highlightcolor='black')
    wheat_entry.place(x=360, y=100, height=40, width=400)
    
    maize_entry = Entry(out_frame, highlightthickness=3, highlightcolor='black')
    maize_entry.place(x=360, y=170, height=40, width=400)
    
    pulse_entry = Entry(out_frame, highlightthickness=3, highlightcolor='black')
    pulse_entry.place(x=360, y=240, height=40, width=400)
    
    # Fill entries with data if available
    if 'name' in globals() and 'value' in globals():
        for i, crop in enumerate(name):
            if crop == "Wheat" and i < len(value):
                wheat_entry.insert(0, value[i])
            elif crop == "Maize" and i < len(value):
                maize_entry.insert(0, value[i])
            elif crop == "Pulse" and i < len(value):
                pulse_entry.insert(0, value[i])
    
    # Labels
    Label(out_frame, text='Wheat', font=('georgia', 25), highlightthickness=3, highlightbackground='black', highlightcolor='black').place(x=220, y=100)
    Label(out_frame, text='Maize', font=('georgia', 25), highlightthickness=3, highlightbackground='black', highlightcolor='black').place(x=220, y=170)
    Label(out_frame, text='Pulse', font=('georgia', 25), highlightthickness=3, highlightbackground='black', highlightcolor='black').place(x=220, y=240)
    
    # Home & Graph analysis button
    Button(out_frame, text='Home', bg='green', fg='white', font=('georgia', 20), command=ready).place(x=830, y=240, height=50, width=100)
    Button(out_frame, text='Graph Analysis', bg='green', fg='white', font=('georgia', 20), command=result).place(x=950, y=240, height=50, width=200)
    
def result():
    
    global r_frame
    
    if d_frame:
        d_frame.place_forget()
    else:
        print("No d_frame")
    
    r_frame = Frame(fapp, bg='palegreen', bd = 2)
    r_frame.place(x=80, y =100, height = 600, width = 1400)
    
    # Add background image
    bg_label = Label(r_frame, image=bg_pht)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
    bg_label.lower()

    Label(r_frame, text = 'Predicted Result', font = ('georgia', 30), fg = 'white', bg = 'black').place(x=530, y=50)
    
    bar_frame = Frame(r_frame, bg = 'white', bd=2)
    bar_frame.place(x=115, y=150, height = 350, width = 1180) 
    
    Button(r_frame, text = 'Home', bg = 'green', fg = 'white',font=('georgia',20) ,command = ready).place(x=850, y=520, height = 50, width = 100)
    Button(r_frame, text = 'Text Analysis', bg = 'green', fg = 'white',font=('georgia',20), command = tent_output).place(x=980, y=520, height = 50, width = 180)
    
    # Graph plot --------------------------------------------------------------
    fig, ax = plt.subplots()
    ax.bar(name, [float(v) for v in value])
    ax.set_xlabel('\n ------------ Crops ------------')
    ax.set_ylabel('------------ Water Demand ------------')
    ax.set_title('Predicted Water Demand')
    canvas = FigureCanvasTkAgg(fig, master=bar_frame)
    canvas.get_tk_widget().pack(fill=BOTH, expand=True)

# Prediction of Primary Crop by getting the user input-------------------------

def Predict_PC():
    global name, value    
    try:
        messagebox.showinfo("Processing", "Loading Please wait...")
        
        # Get input values
        Age = Ageofplant.get()
        moisture = soilmoisture.get()
        shumidity = soilhumidity.get()
        humus = soilhumus.get()
        temp = temprature.get()
        Humidity = humidity.get()
        
        # Input validation
        for input_val in [Age, moisture, shumidity, humus, temp, Humidity]:
            if not input_val:
                messagebox.showerror("Error", "All fields are required")
                return
            try:
                float(input_val)
            except ValueError:
                messagebox.showerror("Error", "Invalid input. Please enter numbers only.")
                return
        
        # Construct URL for Flask API endpoint
        url = f"http://127.0.0.1:5000/predict_water/{Age}/{moisture}/{shumidity}/{humus}/{temp}/{Humidity}"
        
        # Make API request
        response = requests.get(url)
        prediction_result = response.text
        print("Prediction result:", prediction_result)
        
        if "Error" not in prediction_result:
            messagebox.showinfo("Success", "Prediction completed successfully")
            
            # Parse prediction result
            lines = prediction_result.strip().split('\n')
            
            # Initialize lists for crop names and values
            name = []
            value = []
            
            # Extract values for each crop
            for line in lines[1:]:  # Skip the header line
                if ':' in line:
                    parts = line.split(':')
                    crop_name = parts[0].strip()
                    # Extract numeric value before the parenthesis
                    water_value = parts[1].split('(')[0].strip()
                    
                    name.append(crop_name)
                    value.append(water_value)
            
            print("Extracted crop names:", name)
            print("Extracted water values:", value)
            
            # Enable the Predict button to show results
            Button(d_frame, text='View Results', bg='green', fg='white', 
                   font=('arial', 15), command=result).place(x=1150, y=320, height=50, width=150)
        else:
            messagebox.showerror("Error", "Prediction failed")
            
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")
        print(f"Error in prediction: {str(e)}")
        
# *************************************************************PREDICTION OF WATER REQUIRED FOR CROP*******************************************************************************************
      
def predict():
    
    global d_frame
    
    global Ageofplant, soilmoisture, soilhumidity, soilhumus, temprature, humidity
    
    if l_frame:
        l_frame.place_forget()
    
    d_frame = Frame(fapp, bg = 'palegreen',bd = 2)
    d_frame.place(x=120, y =140, height = 460, width = 1300)
    
    #Add background image
    bg_label = Label(d_frame, image=bg_pht)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
    bg_label.lower()
    
    Label(d_frame, text = 'Prediction for Primary Crop', font = ('arial',25), bg='black', fg='white').place(x=460, y=20)
    
    Label(d_frame, text = 'Age of plant', font=('arial',20), bg = 'lightsteelblue').place(x=300, y=110)
    Ageofplant = Entry(d_frame,highlightthickness=2 ,highlightbackground='black')
    Ageofplant.place(x=500, y=110, height = 30, width = 350)
   
    Label(d_frame, text = 'soil moisture', font=('arial',20), bg = 'lightsteelblue').place(x=300, y=160)
    soilmoisture = Entry(d_frame,highlightthickness=2 ,highlightbackground='black')
    soilmoisture.place(x=500, y=160, height = 30, width = 350)
   
    Label(d_frame, text = 'soil humidity', font=('arial',20), bg = 'lightsteelblue').place(x=300, y=210)
    soilhumidity = Entry(d_frame,highlightthickness=2 ,highlightbackground='black')
    soilhumidity.place(x=500, y=210, height = 30, width = 350)
   
    Label(d_frame, text = 'soil humus', font=('arial',20), bg = 'lightsteelblue').place(x=300, y=260)
    soilhumus = Entry(d_frame,highlightthickness=2 ,highlightbackground='black')
    soilhumus.place(x=500, y=260, height = 30, width = 350)
    
    Label(d_frame, text = 'temprature', font=('arial',20), bg = 'lightsteelblue').place(x=300, y=310)
    temprature = Entry(d_frame,highlightthickness=2 ,highlightbackground='black')
    temprature.place(x=500, y=310, height = 30, width = 350)
   
    Label(d_frame, text = 'humidity', font=('arial',20), bg = 'lightsteelblue').place(x=300, y=360)
    humidity = Entry(d_frame,highlightthickness=2 ,highlightbackground='black')
    humidity.place(x=500, y=360, height = 30, width = 350)
    
    
    Button(d_frame, text = 'Predict', bg = 'green', fg = 'white', font=('arial', 15), command = Predict_PC).place(x=1150, y=320, height = 50, width = 100) 
    
import requests
from tkinter import messagebox

# for login button ------------

def Login(event=None):
  userid = id_entry.get()
  passcode = pass_entry.get()
  
  if not userid or not passcode:
      
    messagebox.showerror("Error", "Please enter both UserId and Passcode.")
    return 0

  url = "http://127.0.0.1:5000/securelogin/"+userid+"/"+passcode  
  response = requests.get(url)
  print(response)
  if response.status_code == 200 and response.text.strip() == "Login Successful":
      messagebox.showinfo("Success","Login Successful !")
      predict()
  else:
      messagebox.showerror("Error","Login Failed !")
      
# l_frame Creation 
def ready():
    global id_entry, pass_entry, l_frame
    
    if i_frame:
        i_frame.place_forget()
    else:
        print("i_frame not created")
        return
    
    # Create login frame - SEPARATE creation and placement
    l_frame = Frame(fapp, bg='palegreen', bd=2)
    l_frame.place(x=2, y=5, height=1200, width=1530)
    
    # Add background image to l_frame
    bg_label = Label(l_frame, image=bg_pht)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
    bg_label.lower()
    
    Label(l_frame, text='Secure Login', font=('arial', 25), bg='black', fg='white').place(x=660, y=150)
    Label(l_frame, text='Agricultural UserID', font=('arial', 20), bg='lightsteelblue').place(x=450, y=290)
    
    # Assign Entry widgets to variables before placing them
    id_entry = Entry(l_frame, highlightthickness=2, highlightbackground='black')
    id_entry.place(x=700, y=290, height=30, width=250)
    
    Label(l_frame, text='Passcode', font=('arial', 20), bg='lightsteelblue').place(x=450, y=350)
    pass_entry = Entry(l_frame, highlightthickness=2, highlightbackground='black', show="*")
    pass_entry.place(x=700, y=350, height=30, width=250)
    
    # Enter key to the Login function
    fapp.bind('<Return>', Login)
    
    Button(l_frame, text='Login', bg='green', fg='white', font=('arial', 15), command=Login).place(x=750, y=450, height=50, width=100)

# i_frame Creation
def proceed():
    
    global i_frame
    w_frame.place_forget()
    
    # Create instruction frame --------
    i_frame = Frame(fapp, bg = 'palegreen', bd = 2 )
    i_frame.place(x=2, y =5, height = 1200, width = 1530)
    
    # Add background image
    bg_label = Label(i_frame, image=bg_pht)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
    bg_label.lower()
    
    
    Label(i_frame, text = "Introduction To Project",bg ='black',fg = 'white', font = ('arial',25)).place(x=550,y=30)
    
    # List all the instruction -------
    instruction = ["Frontend", "Backend", "Machine Learning Algorithm - xyz", "Efficiency of Project - 0%", "Project Outcome"]
    
    # Create dynamic component ------- 
    X = 80
    Y = 90
    for i in range(len(instruction)):
        Label(i_frame, text = instruction[i], bg = 'lightsteelblue', font = ('arial',25)).place(x = X, y = Y+80)
        Y=Y+60
    
    # Next button   
    Button(i_frame, text = 'Next', bg = 'green', fg = 'white',font=('arial',15), command = ready).place(x=1150, y=380, height = 50, width = 100)




# Main Website creation 
# w_frame creation 
fapp = Tk()
fapp.state('zoomed')

# Load the background image once globally
global bg_pht  # Make it global so all functions can access it
bg_img = Image.open("imgbg.JFIF")
bg_pht = ImageTk.PhotoImage(bg_img.resize((1500, 1200)))


# Display the welcome frame of Project 
w_frame = Frame(fapp, bg = 'palegreen', bd = 2 )
w_frame.place(x=2, y =5, height = 1200, width = 1530)

# Background image //////////////////////////////////////////////////
bg_img = Image.open("imgbg.JFIF")
bg_pht = ImageTk.PhotoImage(bg_img.resize((1500,1200)))
bg_label = Label(w_frame, image = bg_pht)
bg_label.place(x=0 , y=0, relwidth = 1, relheight = 1)
bg_label.lower()

from PIL import Image, ImageTk  

# Check if `Image` is not overwritten
print(type(Image))  # Should print <class 'module'>

# Load and display image
image = Image.open('logo.JFIF')  #  Ensure correct file path
image.thumbnail((150, 150), Image.LANCZOS)
photo = ImageTk.PhotoImage(image)

# Attach to Tkinter Label
p_label = Label(w_frame, image=photo, highlightthickness=2, highlightcolor='black', highlightbackground='black')
p_label.photo = photo  # Prevent garbage collection
p_label.place(x=680, y=150)


# Display the title of the project
Label(w_frame, text = "Water Demand Prediction in an agriculture field \n for the primary crop using machine learning", font=('timesnewroman',30), bg = 'lightsteelblue', fg = 'black').place(x=350, y=350)

# Proceed button
Button(w_frame, text = 'Proceed', bg = 'green', fg = 'white', font=('arial',15) ,command = proceed).place(x=700, y=550, height = 50, width = 100)



# main loop for running the program 
fapp.mainloop()