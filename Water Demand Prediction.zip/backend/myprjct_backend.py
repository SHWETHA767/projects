from flask import Flask, request
import pandas as pd
import os
import csv
from tkinter import messagebox
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import MinMaxScaler
import openpyxl

app = Flask(__name__)


# ************************* SECURE LOGIN FUNCTION ******************************************

@app.route('/securelogin/<UserID>/<Passcode>')

def securelogin(UserID, Passcode):
    # Load the credentials from the CSV file
    data = pd.read_csv('credential.csv')

    # Ensure column names and values are stripped of whitespaces
    data.columns = data.columns.str.strip()
    data['UserID'] = data['UserID'].astype(str).str.strip()
    data['Passcode'] = data['Passcode'].astype(str).str.strip()

    # Strip input values to ensure proper comparison
    UserID, Passcode = UserID.strip(), Passcode.strip()
     

    # Check if a matching UserID and Passcode exist
    if ((data['UserID'] == UserID) & (data['Passcode'] == Passcode)).any():
        return "Login Successful"
    else:
        return "Login Failed"
    

def save_data_to_excel(Age,moisture,shumidity,humus, temp, humidity,wtaerrequired, fname):  
    try:
        if not os.path.exists(fname):
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            header = ['Ageofplant', 'soilmoisture', 'soilhumidity', 'soilhumus', 'temprature', 'humidity', 'waterrequired']
            sheet.append(header)
            workbook.save(fname)
        
        wb = openpyxl.load_workbook(fname)
        sheet = wb.active
        next_row = sheet.max_row + 1
        
        sheet.cell(row=next_row ,column=1).value = Age
        sheet.cell(row=next_row ,column=2).value = moisture
        sheet.cell(row=next_row ,column=3).value = shumidity
        sheet.cell(row=next_row ,column=4).value = humus
        sheet.cell(row=next_row ,column=5).value = temp
        sheet.cell(row=next_row ,column=6).value = humidity
        sheet.cell(row=next_row, column=7).value = waterrequired
        
        wb.save(fname)
        return "data inserted successfully"
    except Exception as e:
        return f"insertion failed: {str(e)}"
    
@app.route('/predict_water/<Age>/<moisture>/<shumidity>/<humus>/<temp>/<Humidity>')
def predict_water(Age,moisture,shumidity,humus, temp, Humidity):
    try:  
        response_text = "Predicted Water Requirement: \n"           
        for crop in ['wheat', 'maize', 'pulse']:
            fname = f"{crop}dataset.xlsx"
            crop_data = pd.read_excel(fname)
            print("CSV data read successfully")
            print("Crop data ----------\n",crop_data)
            crop_data.columns = crop_data.columns.str.strip()
            
            crop_data.dropna(inplace=True) # Remove rows with NaNs after conversion
            
            X = crop_data[['Ageofplant', 'soilmoisture','soilhumidity','soilhumus','temprature','humidity']] 
            Y = crop_data['waterrequired']
            
            scaler = MinMaxScaler()
            X_scaled = scaler.fit_transform(X)
            
            model = DecisionTreeClassifier()
            model.fit(X_scaled, Y)
            
            input_data = pd.DataFrame([[Age,moisture,shumidity,humus,temp,Humidity]], columns = X.columns)
            input_data_scaled = scaler.transform(input_data)
            
            prediction = model.predict([[float(Age),float(moisture),float(shumidity),float(humus),float(temp),float(Humidity)]])[0]
            
            save_status = save_data_to_excel(Age,moisture,shumidity,humus, temp, Humidity, prediction, f"{crop}_predictions.xlsx")  
            
            response_text += f"{crop.capitalize()}: {prediction} (Save Status: {save_status}) \n"
        print("Successfully saved !!!!")
        return response_text    
        
    except Exception as e:
        return f"Error: {str(e)}"


if __name__ == '__main__':
    app.run()