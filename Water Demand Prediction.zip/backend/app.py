from flask import Flask, render_template, request

app = Flask(__name__)

# Route for the welcome page
@app.route('/')
def welcome():
    return render_template('welcome.html')  # This serves welcome.html

# Route for the login page
@app.route('/login')
def login():
    return render_template('login.html')  # This serves login.html

# Route for handling secure login (optional functionality)
@app.route('/securelogin', methods=['POST'])
def secure_login():
    user_id = request.form['UserID']
    passcode = request.form['Passcode']

    # Add logic here to verify user credentials (e.g., from a database or file)
    if user_id == "admin" and passcode == "1234":  # Example credentials
        return "Login Successful!"
    else:
        return "Invalid Credentials! Try Again."

if __name__ == "__main__":
    app.run()
