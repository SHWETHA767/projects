# **********Water Demand Prediction in an agriculture field \n for the primary crop using machine learning****************

from tkinter import *
from PIL import Image, ImageTk


# ***********************************************Output Frame*********************************************************

def tent_output():
    
    global t_frame
    
    # forgetting the r_frame ---------------------------------------------
    if r_frame is not None:
        r_frame.place_forget()
    
    # t_frame creation -----------------------------------------
    t_frame = Frame(fapp, bg = 'lightsteelblue', bd = 2).place(x=120, y =140, height = 460, width = 1300)
    
    # out_frame creation inside the t_frame-----------------------------------
    out_frame = Frame(t_frame, bg = 'white', bd=2).place(x=170, y=210, height = 300, width = 1200)
    
    Label(out_frame, text = 'The Water Prediction Result', bg='black', fg='white', font=('arial',20)).place(x=550, y=150)
    
    
    Label(out_frame, text = 'Wheat', font=('arial',20), highlightthickness=3, highlightbackground='black' ,highlightcolor='black').place(x=390, y=300)
    Entry(out_frame,highlightthickness=3, highlightcolor='black').place(x=530,y=300,height=40, width = 400)
    
    
    Label(out_frame, text = 'Maize ', font=('arial',20), highlightthickness=3, highlightbackground='black' ,highlightcolor='black').place(x=390, y=350)
    Entry(out_frame,highlightthickness=3, highlightcolor='black').place(x=530,y=350,height=40, width = 400)
    
    
    Label(out_frame, text = 'Paddy', font=('arial',20), highlightthickness=3, highlightbackground='black' ,highlightcolor='black').place(x=390, y=400)
    Entry(out_frame,highlightthickness=3, highlightcolor='black').place(x=530,y=400,height=40, width = 400)
    
    
    # Home & Graph analysis button --------------------
    Button(out_frame, text = 'Home', bg = 'green', fg = 'white',font=('arial',15)).place(x=1080, y=520, height = 50, width = 100)
    Button(out_frame, text = 'Graph Analysis', bg = 'green', fg = 'white', font=('arial',15)).place(x=1200, y=520, height = 50, width = 180)

    


# Home button --------------
#def home_btm():
    #pass

# text Analysis button ------------
#def text_analysis_btm():
   # pass


def result():
    
    global r_frame
    
    d_frame.place_forget()
    
    r_frame = Frame(fapp, bg='lightsteelblue', bd = 2).place(x=120, y =140, height = 460, width = 1300)

    Label(r_frame, text = 'Predicted Result', font = ('arial', 25), bg = 'black', fg = 'white').place(x=650, y=150)
    
    bar_frame = Frame(r_frame, bg = 'white', bd=2).place(x=170, y=210, height = 300, width = 1200)

    Button(r_frame, text = 'Home', bg = 'green', fg = 'white',font=('arial',15) ,command = tent_output).place(x=1080, y=520, height = 50, width = 100)
    Button(r_frame, text = 'Text Analysis', bg = 'green', fg = 'white',font=('arial',15), command = tent_output).place(x=1200, y=520, height = 50, width = 180)



    
# For predict button --------------------------------------------

def predict_demand():
    p1 = float(entry_p1.get())
    p2 = float(entry_p2.get())
    p3 = float(entry_p3.get())
    p4 = float(entry_p4.get())
    

# Secure Login --------------------------------------------------------------------------------

def predict():
    
    global d_frame
    
    l_frame.place_forget()
    d_frame = Frame(fapp, bg = 'lightsteelblue',bd = 2)
    d_frame.place(x=120, y =140, height = 460, width = 1300)
    
    Label(d_frame, text = 'Prediction for Primary Crop', font = ('arial',25), bg='black', fg='white').place(x=400, y=40)
    
    Label(d_frame, text = 'P1', font=('arial',20), bg = 'lightsteelblue').place(x=350, y=150)
    Entry(d_frame,highlightthickness=2 ,highlightbackground='black').place(x=400, y=150, height = 30, width = 250)
   
    Label(d_frame, text = 'P2', font=('arial',20), bg = 'lightsteelblue').place(x=350, y=200)
    Entry(d_frame,highlightthickness=2 ,highlightbackground='black').place(x=400, y=200, height = 30, width = 250)
   
    Label(d_frame, text = 'P3', font=('arial',20), bg = 'lightsteelblue').place(x=350, y=250)
    Entry(d_frame,highlightthickness=2 ,highlightbackground='black').place(x=400, y=250, height = 30, width = 250)
   
    Label(d_frame, text = 'P4', font=('arial',20), bg = 'lightsteelblue').place(x=350, y=300)
    Entry(d_frame,highlightthickness=2 ,highlightbackground='black').place(x=400, y=300, height = 30, width = 250)
   
    Button(d_frame, text = 'Predict', bg = 'green', fg = 'white', font=('arial', 15), command = result).place(x=750, y=300, height = 50, width = 100)
    





# for login button ------------
def Login():
    pass


# l_frame Creation ---------------------------------------------------------------------------

def ready():
    i_frame.place_forget()
    
    global l_frame
    
    # Create frame according to features of a application ----------
    l_frame = Frame(fapp, bg = 'lightsteelblue',bd = 2)
    l_frame.place(x=120, y =140, height = 460, width = 1300)
    
    Label(l_frame, text = 'Secure Login', font = ('arial',25), bg='black', fg='white').place(x=500, y=40)
    Label(l_frame, text = 'Agricultural UserID', font=('arial',20), bg = 'lightsteelblue').place(x=250, y=150)
    Entry(l_frame,highlightthickness=2 ,highlightbackground='black').place(x=500, y=150, height = 30, width = 250)
    Label(l_frame, text = 'Passcode', font=('arial',20), bg = 'lightsteelblue').place(x=250, y=200)
    Entry(l_frame,highlightthickness=2 ,highlightbackground='black').place(x=500, y=200, height = 30, width = 250)
   
    Button(l_frame, text = 'Login', bg = 'green', fg = 'white',font=('arial',15), command = predict).place(x=550, y=300, height = 50, width = 100)




# i_frame Creation ---------------------------------------------------------------------------

def proceed():
    
    global i_frame
    w_frame.place_forget()
    
    # Create instruction frame --------
    i_frame = Frame(fapp, bg = 'lightsteelblue', bd = 2 )
    i_frame.place(x=120, y =140, height = 460, width = 1300)
    
    Label(i_frame, text = "Introduction To Project",bg ='black',fg = 'white', font = ('arial',30)).place(x=350,y=30)
    
    # List all the instruction -------
    instruction = ["Frontend", "Backend", "Machine Learning Algorithm - xyz", "Efficiency of Project - 0%", "Project Outcome"]
    
    # Create dynamic component -------
    X = 40
    Y = 70
    for i in range(len(instruction)):
        Label(i_frame, text = instruction[i], bg = 'lightsteelblue', font = ('arial',25)).place(x = X, y = Y+60)
        Y=Y+60
    
    # Next button --------    
    Button(i_frame, text = 'Next', bg = 'green', fg = 'white',font=('arial',15), command = ready).place(x=1150, y=380, height = 50, width = 100)


    

#main application
fapp = Tk()
fapp.state('zoomed')

#welcome_frame
# Display the welcome frame of Project -----------
w_frame = Frame(fapp, bg = 'lightsteelblue', bd = 2 )
w_frame.place(x=120, y =140, height = 460, width = 1300)

# Display the logo on the frame -------
image = Image.open('logo.JFIF')
image.thumbnail((500, 500), Image.ANTIALIAS)

# Display the image -------
photo = ImageTk.PhotoImage(image)
p_label = Label(w_frame, image = photo, highlightthickness=2, highlightcolor='black', highlightbackground='black')
p_label.place(x=18,y=18)

# Display the title of the project --------
Label(w_frame, text = "Water Demand Prediction in an agriculture field \n for the primary crops using Decision Tree & \n  KNN algorithm", font=('timesnewroman',30), bg = 'lightsteelblue', fg = 'black').place(x=300, y=120)

# Proceed button ---------
Button(w_frame, text = 'Proceed', bg = 'green', fg = 'white', font=('arial',15) ,command = proceed).place(x=1150, y=380, height = 50, width = 100)





# main loop for running the program ---------------------------
fapp.mainloop()