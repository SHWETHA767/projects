import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import json
import os
import pandas as pd
import cv2  # Import OpenCV for camera feed
import random  # Import random for selecting questions

# Initialize main window FIRST
fapp = tk.Tk()
fapp.state('zoomed')
fapp.title("Online Exam Proctoring System")

USERS_FILE = "users.json"
if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, "w") as f:
        json.dump([], f)

# Tkinter variables
current_user = tk.StringVar()
student_id = tk.StringVar()
student_password = tk.StringVar()
signup_name = tk.StringVar()
signup_id = tk.StringVar()
signup_password = tk.StringVar()
signup_confirm_password = tk.StringVar()
TC_var = tk.IntVar()

# Load background image
def set_background(frame):
    bg_image = Image.open('new_background.jpg')  # Update with the path to your image
    bg_image = bg_image.resize((2000, 1400))  # Resize if necessary
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = tk.Label(frame, image=bg_photo)
    bg_label.image = bg_photo  # Keep a reference to avoid garbage collection
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# ======================== Authentication System ========================
def register_user():
    """Save new user credentials to JSON file"""
    new_user = {
        "name": signup_name.get(),
        "student_id": signup_id.get(),
        "password": signup_password.get()
    }
    
    if not all([new_user["name"], new_user["student_id"], new_user["password"], signup_confirm_password.get()]):
        messagebox.showerror("Error", "All fields are required!")
        return
    
    if new_user["password"] != signup_confirm_password.get():
        messagebox.showerror("Error", "Passwords do not match!")
        return
    
    with open(USERS_FILE, "r+") as f:
        users = json.load(f)
        if any(user["student_id"] == new_user["student_id"] for user in users):
            messagebox.showerror("Error", "Student ID already exists!")
            return
        users.append(new_user)
        f.seek(0)
        json.dump(users, f)
    
    messagebox.showinfo("Success", "Registration successful!")
    Login_frame()

def validate_login():
    """Check login credentials against stored users"""
    input_id = student_id.get()
    input_password = student_password.get()
    
    with open(USERS_FILE, "r") as f:
        users = json.load(f)
        for user in users:
            if user["student_id"] == input_id and user["password"] == input_password:
                current_user.set(user["name"])
                save_login_data(user)  # Save login data to Excel
                select_random_questions()  # Select 5 random questions
                main_frame()  # Call the main frame function
                return
    
    messagebox.showerror("Error", "Invalid Student ID or Password")
    student_id.set("")
    student_password.set("")

def save_login_data(user):
    """Save login data to an Excel file."""
    login_data_file = "login_data.xlsx"  # File for login data
    
    # Create a DataFrame from the user data
    df = pd.DataFrame({
        "Name": [user["name"]],
        "Student ID": [user["student_id"]],
        "Login Time": [pd.Timestamp.now()],
        "Score": [0]  # Initialize score to 0, will update after exam
    })
    
    # Append to existing file or create new file
    try:
        if os.path.exists(login_data_file):
            # Append to existing file
            with pd.ExcelWriter(login_data_file, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
                df.to_excel(writer, index=False, header=False)  # No header when appending
        else:
            # Create new file with header
            df.to_excel(login_data_file, index=False, header=True)  # Include header
    except Exception as e:
        messagebox.showerror("Error", f"Failed to save login data: {str(e)}")

def save_exam_results(user):
    """Save exam results to a separate Excel file."""
    data_file = "data.xlsx"  # File for exam results
    
    # Create a DataFrame for the results
    result_df = pd.DataFrame({
        "Student ID": [user["student_id"]],
        "Score": [score],
        "Exam Completion Time": [pd.Timestamp.now()],
        "Malpractice Detected": [malpractice_detected]  # Add malpractice status
    })
    
    # Append the results to the existing file
    try:
        if os.path.exists(data_file):
            with pd.ExcelWriter(data_file, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
                result_df.to_excel(writer, index=False, header=False)  # No header when appending
        else:
            result_df.to_excel(data_file, index=False, header=True)  # Include header
    except Exception as e:
        messagebox.showerror("Error", f"Failed to save exam results: {str(e)}")

# ======================== Load Questions from Excel ========================
def load_questions_from_excel(file_path):
    df = pd.read_excel(file_path)
    questions = []
    
    for index, row in df.iterrows():
        question = {
            "question": row["Question"],
            "options": [row["Option A"], row["Option B"], row["Option C"], row["Option D"]],
            "answer": row["Correct Answer"]
        }
        questions.append(question)
    
    return questions

# Load questions from the Excel file
all_questions = load_questions_from_excel("mcq.xlsx")
selected_questions = []  # Global variable to hold the selected questions

def select_random_questions():
    """Select 5 random questions from the loaded questions."""
    global selected_questions
    selected_questions = random.sample(all_questions, 5)  # Select 5 random questions
                                                                                
# ======================== UI Frames ========================
def processed():
    wframe.place_forget()
    iframe = tk.Frame(fapp, bg='#e0f7fa')
    iframe.place(x=0, y=0, relwidth=1, relheight=1)
    set_background(iframe)  # Set background image

    instructions = [
        "Project Name: Online Proctoring System",
        "Features:",
        "- Secure Login/Signup",
        "- Timed Exams",
        "- Automatic Grading",
        "- Result Review"
    ]
    
    y = 50
    for text in instructions:
        tk.Label(iframe, text=text, bg='#e0f7fa', font=('Helvetica', 14)).place(x=100, y=y)
        y += 40
    
    tk.Button(iframe, text="Continue", command=Login_frame, font=('Helvetica', 14), bg='#0b2644', fg='white', highlightbackground='white', highlightcolor='white').place(x=100, y=300)

# ======================== Global Variables ========================
current_question = 0
score = 0
timer_id = None
time_left = 45 
user_answers = [] 
camera_cap = None  # Global variable to hold camera capture object
malpractice_detected = False  # Flag to indicate if malpractice was detected

# ======================== Core Functions ========================
def Login_frame():
    wframe.place_forget() 
    global lframe
    lframe = tk.Frame(fapp, bg='#e0f7fa', bd=2)
    lframe.place(x=0, y=0, height=1400, width=2000)
    set_background(lframe)  # Set background image
    
    # Login page widgets
    tk.Label(lframe, text="Login Page", bg='#e0f7fa', font=('Helvetica', 30, 'bold')).place(x=700, y=100)
    tk.Label(lframe, text='Student ID', font=('Helvetica', 18)).place(x=450, y=200)
    tk.Entry(lframe, textvariable=student_id, font=('Helvetica', 16)).place(x=700, y=200, height=30, width=270)
    tk.Label(lframe, text='Password', font=('Helvetica', 18)).place(x=450, y=300)
    tk.Entry(lframe, textvariable=student_password, show='*', font=('Helvetica', 16)).place(x=700, y=300, height=30, width=270)
    tk.Button(lframe, text='Login', command=validate_login, font=('Helvetica', 18), bg='#0b2644', fg='white', highlightbackground='white', highlightcolor='white').place (x=750, y=400)
    tk.Button(lframe, text='SIGN UP', command=SignUp_frame, font=('Helvetica', 18), bg='#0b2644', fg='white', highlightbackground='white', highlightcolor='white').place(x=1050, y=700)

def SignUp_frame():
    lframe.place_forget() 
    global Su_frame
    Su_frame = tk.Frame(fapp, bg='#e0f7fa', bd=2)
    Su_frame.place(x=0, y=0, height=1400, width=2000)
    set_background(Su_frame)  # Set background image
    
    # Signup widgets
    tk.Label(Su_frame, text='CREATE NEW ACCOUNT', bg='#e0f7fa', font=('Helvetica', 30, 'bold')).place(x=600, y=100)
    tk.Label(Su_frame, text='Student Name', bg='#e0f7fa', font=('Helvetica', 18)).place(x=250, y=200)
    tk.Entry(Su_frame, textvariable=signup_name, font=('Helvetica', 16)).place(x=700, y=200, height=30, width=270)
    tk.Label(Su_frame, text='Student ID', bg='#e0f7fa', font=('Helvetica', 18)).place(x=250, y=300)
    tk.Entry(Su_frame, textvariable=signup_id, font=('Helvetica', 16)).place(x=700, y=300, height=30, width=270)
    tk.Label(Su_frame, text='Password', bg='#e0f7fa', font=('Helvetica', 18)).place(x=250, y=400)
    tk.Entry(Su_frame, textvariable=signup_password, show='*', font=('Helvetica', 16)).place(x=700, y=400, height=30, width=270)
    tk.Label(Su_frame, text='Confirm Password', bg='#e0f7fa', font=('Helvetica', 18)).place(x=250, y=500)
    tk.Entry(Su_frame, textvariable=signup_confirm_password, show='*', font=('Helvetica', 16)).place(x=700, y=500, height=30, width=270)
    tk.Button(Su_frame, text='Register', command=register_user, font=('Helvetica', 18), bg='blue', fg='white', highlightbackground='white', highlightcolor='white').place(x=1050, y=700)

def show_terms():
    terms_window = tk.Toplevel(fapp)
    terms_window.title("Terms and Conditions")
    terms_window.geometry("800x600")  # Adjusted size for better fit
    terms_window.configure(bg='#114076')  # Set the background color of the window

    # Create a frame for the terms and conditions
    terms_frame = tk.Frame(terms_window, bg='#114076')
    terms_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

    # Create a scrollable text area for the terms
    terms_text = """\
    Terms and Conditions for Online Exam Proctoring

    1. Acceptance of Terms:
       By participating in the online exam, you agree to abide by these terms and conditions. Failure to comply may result in disqualification or other penalties.

    2. Eligibility:
       Only registered students with a valid student ID are allowed to take the exam. Each student must use their own account and credentials.

    3. Exam Conduct:
       - No cheating or use of unauthorized materials is allowed during the exam.
       - The exam must be taken in a quiet environment without any assistance from other individuals.
       - Any form of communication with other participants during the exam is strictly prohibited.
       - Proctoring software will be used to monitor your activity during the exam.

    4. Technical Requirements:
       - Ensure a stable internet connection throughout the exam duration.
       - Use a compatible device (computer, tablet, etc.) with the necessary software and hardware requirements.
       - Disable any browser extensions or software that may interfere with the exam platform.

    5. Privacy and Data Security:
       - Personal information collected during the registration and exam process will be used solely for the purpose of administering the exam and ensuring compliance with these terms.
       - Data will be stored securely and not shared with third parties without consent, except as required by law.

    6. Exam Duration and Timing:
       - The total duration of the exam is 30 minutes.
       - Each question carries one mark, and there is no negative marking.
       - The exam consists of 5 questions.
       - Once the exam starts, it must be completed within the allotted time. No extensions will be granted.
       - You are allowed to take the exam only once.

    7. Submission of Answers:
       - Mark your answers by clicking the correct radio button . To change your answer, click the radio button that you think is correct.
       - Once you click "Finish Test," your answers will be submitted, and the exam will be considered complete.
       - No changes or submissions will be allowed after the exam time has expired.

    8. Liability:
       - The exam administrators are not responsible for any technical issues, disruptions, or other circumstances beyond their control that may affect the exam process.
       - Participants are responsible for ensuring their devices and internet connections meet the required standards.

    9. Disqualification:
       - Any violation of these terms and conditions may result in immediate disqualification and potential disciplinary action.
       - The exam administrators reserve the right to investigate and take necessary actions against any form of misconduct.

    10. Modifications to Terms:
        - The exam administrators reserve the right to modify these terms and conditions at any time. Participants will be notified of any changes before the exam.
    """

    # Create a scrollable text widget
    text_area = tk.Text(terms_frame, wrap=tk.WORD, bg='white', font=('Helvetica', 10))
    text_area.insert(tk.END, terms_text)
    text_area.config(state=tk.DISABLED)  # Make the text area read-only
    text_area.pack(fill=tk.BOTH, expand=True)

    # Create a frame for the checkbox and button
    checkbox_frame = tk.Frame(terms_frame, bg='white')
    checkbox_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=10)

    TC_var = tk.IntVar()

    TC_checkbox = tk.Checkbutton(checkbox_frame, text='I agree to the Terms and Conditions', variable=TC_var, bg='white', activebackground="white", font=("Arial", 12))
    TC_checkbox.pack(side=tk.LEFT, padx=10)

    # Close button
    def on_close():
        if TC_var.get():
            terms_window.destroy()
        else:
            messagebox.showwarning("Warning", "You must agree to the terms and conditions to proceed.")
    
    close_button = tk.Button(checkbox_frame, text="Close", command=on_close, bg='#0b2644', fg='white')
    close_button.pack(side=tk.RIGHT, padx=10)

def show_exam_start_message():
    """Show a message box indicating that the exam is starting."""
    messagebox.showinfo("Exam Starts Now", "The exam starts now!")
    # After 3 seconds, proceed to the exam frame
    fapp.after(3000, start_exam)

def start_exam():
    """Start the exam after showing the message."""
    global malpractice_detected
    malpractice_detected = False  # Reset the flag
    if fapp.winfo_exists():  # Check if the main window still exists
        Exam_frame() 

def main_frame():  # Renamed from Main_frame to main_frame
    lframe.place_forget()  
    global main_frame_instance  # Renamed variable
    main_frame_instance = tk.Frame(fapp, bg='#0b2644', bd=2)
    main_frame_instance.place(x=0, y=0, height=1400, width=2000)
    set_background(main_frame_instance)  # Set background image
    
    # Main frame widgets
    tk.Label(main_frame_instance, text='EXAM INSTRUCTION', font=('Helvetica', 30, 'bold')).place(x=550, y=30)
    instructions = [
        "• Total 10 questions (30 minutes duration)",
        "• Each question carries 1 mark (no negative marking)",
        "• Select answers using radio buttons",
        "• Click 'Finish Test' to submit",
        "• Click Start to begin"
    ]
    
    y_pos = 120
    for text in instructions:
        tk.Label(main_frame_instance, text=text, bg='white', font=('Helvetica', 17)).place(x=380, y=y_pos)
        y_pos += 30
    
    tk.Button(main_frame_instance, text='Terms and Conditions', command=show_terms, font=('Helvetica', 15), bg='#0b2644', fg='white', highlightbackground='white', highlightcolor='white').place(x=775, y=470)
    tk.Button(main_frame_instance, text='Start', command=show_exam_start_message, font=('Helvetica', 18), bg='#0b2644', fg='white', highlightbackground='white', highlightcolor='white').place(x=1050, y=700)
    
    # Exit button
    tk.Button(main_frame_instance, text='Exit', command=fapp.quit, font=('Helvetica', 18), bg='red', fg='white', highlightbackground='white', highlightcolor='white').place(x=1050, y=800)

# ======================== Camera Feed Management ========================
def start_camera_feed():
    """Start the camera feed in the exam frame."""
    global camera_cap, malpractice_detected
    camera_cap = cv2.VideoCapture(0)

    if not camera_cap.isOpened():
        messagebox.showerror("Error", "Could not open camera.")
        return

    def update_camera():
        ret, frame = camera_cap.read()
        if ret:
            # Convert the frame to RGB format
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # Convert the frame to a PhotoImage
            img = Image.fromarray(frame)
            imgtk = ImageTk.PhotoImage(image=img)
            camera_label.imgtk = imgtk
            camera_label.configure(image=imgtk)

            # Malpractice detection logic
            if detect_malpractice(frame):
                stop_camera_feed()  # Stop the camera feed
                global malpractice_detected
                malpractice_detected = True  # Set the flag
                messagebox.showwarning("Warning", "Malpractice detected! The exam will be terminated.")
                show_results()  # Show results immediately
                return

        camera_label.after(100, update_camera)  # Update every 100 ms

    update_camera()

def stop_camera_feed():
    """Stop the camera feed if it's running."""
    global camera_cap
    if camera_cap is not None:
        camera_cap.release()
        camera_cap = None

def detect_malpractice(frame):
    """Detect potential malpractice by checking for multiple faces."""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    detected_faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

    # If more than one face is detected, consider it malpractice
    if len(detected_faces) > 1:
        return True

    return False

def Exam_frame():
    main_frame_instance.place_forget()
    global exam_frame_instance, current_question, score, time_left, timer_id
    exam_frame_instance = tk.Frame(fapp, bg='#0b2644', bd=2)
    exam_frame_instance.place(x=0, y=0, relwidth=1, relheight=1)
    set_background(exam_frame_instance)  # Set background image
    
    current_question = 0
    score = 0
    time_left = 30
    timer_id = None  # Initialize timer_id

    # Create a label for the camera feed
    global camera_label
    camera_label = tk.Label(exam_frame_instance)
    camera_label.grid(row=0, column=1, rowspan=10, padx=20, pady=20)  # Place camera on the right

    # Start the camera feed for the exam after a short delay
    fapp.after(100, start_camera_feed)  # Start camera feed after 100 ms

    show_question()

def show_question():
    global timer_id, time_left
    # Clear previous question
    for widget in exam_frame_instance.winfo_children():
        if widget != camera_label:  # Keep the camera label
            widget.destroy()
    
    q = selected_questions[current_question]  # Use selected questions
    tk.Label(exam_frame_instance, text=f"Question {current_question + 1}/{len(selected_questions)}", 
             font=('Helvetica', 14)).grid(row=0, column=0, pady=10, padx=10)  # Adjusted column to 0
    
    tk.Label(exam_frame_instance, text=q["question"], font=('Helvetica', 16, 'bold')).grid(row=1, column=0, pady=20, padx=10)  # Adjusted column to 0
    
    # Create a list to hold IntVar for each option
    option_vars = []
    
    for index, option in enumerate(q["options"]):
        var = tk.IntVar(value=0)  # Initialize each checkbox variable
        option_vars.append(var)
        tk.Checkbutton(exam_frame_instance, text=option, variable=var, font=('Helvetica', 14)).grid(row=index + 2, column=0, sticky='w', padx=50)  # Adjusted column to 0
    
    timer_label = tk.Label(exam_frame_instance, text=f"Time Left: {time_left}s", font=('Helvetica', 12))
    timer_label.grid(row=len(q["options"]) + 2, column=0, pady=10)  # Adjusted column to 0

    def update_timer():
        global time_left, timer_id
        time_left -= 1
        if time_left >= 0:
            if timer_label.winfo_exists():  # Check if the label still exists
                timer_label.config(text=f"Time Left: {time_left}s")
                timer_id = exam_frame_instance.after(1000, update_timer)
            else:
                return  # Exit if the label no longer exists
        else:
            # Show warning when time is up
            messagebox.showwarning("Time's Up", "Your time is up! The exam will be submitted now.")
            next_question(option_vars)

    update_timer()
    
    btn_text = "Next Question" if current_question < len(selected_questions) - 1 else "Finish Exam"
    tk.Button(exam_frame_instance, text=btn_text, command=lambda: confirm_finish(option_vars), font=('Helvetica', 14), bg='blue', fg='white', highlightbackground='white', highlightcolor='white').grid(row=len(q["options"]) + 3, column=0, pady=20)

def confirm_finish(option_vars):
    """Confirm if the user wants to finish the exam."""
    if current_question < len(selected_questions) - 1:
        next_question(option_vars)
    else:
        if messagebox.askyesno("Finish Exam", "Are you sure you want to finish the exam?"):
            stop_camera_feed()  # Stop the camera feed before showing results
            show_results()

def next_question(option_vars):
    global current_question, score
    # Check which options are selected
    selected_options = [var.get() for var in option_vars]
    
    # Get the correct answer for the current question
    correct_answer = selected_questions[current_question]["answer"]
    
    # Store the user's selected answer
    user_answer = selected_questions[current_question]["options"][selected_options.index(1)] if 1 in selected_options else None
    user_answers.append(user_answer)  # Store the user's answer
    
    # Check if the selected options match the correct answer
    if user_answer == correct_answer:
        score += 1
    
    if current_question < len(selected_questions) - 1:
        current_question += 1
        show_question()
    else:
        # Ensure the last answer is stored before showing results
        user_answers.append(user_answer)  # Store the last answer
        show_results()

def show_results():
    stop_camera_feed()  # Ensure the camera is stopped before showing results
    for widget in exam_frame_instance.winfo_children():
        widget.destroy()
    
    result_frame = tk.Frame(exam_frame_instance, bg='#e0f7fa')
    result_frame.pack(pady=100, padx=20, fill=tk.BOTH, expand=True)
    
    tk.Label(result_frame, text="Exam Results", font=('Helvetica', 20, 'bold')).pack(pady=20)
    
    if malpractice_detected:
        tk.Label(result_frame, text="Malpractice Detected! Exam results are invalid.", font=('Helvetica', 18)).pack(pady=10)
    else:
        tk.Label(result_frame, text=f"Score: {score}/{len(selected_questions)}", font=('Helvetica', 18)).pack(pady=10)
    
        # Save the exam results

        save_exam_results({"student_id": student_id.get(), "name": current_user.get()})

        tk.Label(result_frame, text="Correct Answers:", font=('Helvetica', 16)).pack(pady=10)
        for i, q in enumerate(selected_questions):
            user_answer = user_answers[i] if i < len(user_answers) else "No answer"
            text = f"Q{i+1}: {q['question']}\nYour Answer: {user_answer}\nCorrect Answer: {q['answer']}\n"
            tk.Label(result_frame, text=text, font=('Helvetica', 12), justify='left', bg='#e0f7fa').pack(anchor='w', padx=10)

    # Exit button in results frame
    tk.Button(result_frame, text="Exit", command=fapp.destroy, font=('Helvetica', 16), bg='red', fg='white', highlightbackground='white', highlightcolor='white').pack(pady=20)

# Welcome Frame
wframe = tk.Frame(fapp, bg='white', bd=2)
wframe.place(x=0, y=0, height=1400, width=2000)
set_background(wframe)  # Set background image
# Create a frame for the image with a border
image_frame = tk.Frame(wframe, bg='#0b2644', bd=5)  # Set the border color and width
image_frame.place(x=10, y=10)  # Position the frame

try:
    image = Image.open('Collegelogo3.jpg')
    image.thumbnail((1000, 1000))
    photo = ImageTk.PhotoImage(image)
    
    # Place the image inside the frame
    tk.Label(image_frame, image=photo).pack()  # Use pack to fill the frame
except Exception as e:
    print(f"Error loading image: {e}")

tk.Label(wframe, text="Online Proctoring Examination System", bg='white', 
        font=('Helvetica', 24, 'bold')).place(x=500, y=170)
tk.Button(wframe, text="Get Started", font=('Helvetica', 16, 'bold'), command=processed, 
          bg='#0b2644', fg='white', highlightbackground='white', highlightcolor='white').place(x=720, y=270)

# Start main loop
fapp.mainloop()